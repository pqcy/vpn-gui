#!/bin/sh
sudo ip link del dum0
sudo pkill dhclient
